A Pen created at CodePen.io. You can find this one at https://codepen.io/justinklemm/pen/zAdoJ.

 Built for the Rodeo Season #2, Week #3 Challenge: "A Shopping Cart"

All functionality and calculations are implemented via Javascript. There are responsive breakpoints at 650px and 350px (though you can't view the latter in Chrome because it won't scale down below 400px). Breakpoints are based on logical UI decisions, not particular device specifications.